interface SpotlightCardProps {
  icon: React.ReactNode
  title: string
  description: string
}
