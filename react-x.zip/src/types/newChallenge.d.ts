export interface NewChallenge {
  lesson: number
  files: Record<string, string>
}
