export interface QuizzProps {
  onSuccess: () => Promise<void>
  onContinue: () => void
}
