export type QuizzStatus = 'idle' | 'success' | 'error'
