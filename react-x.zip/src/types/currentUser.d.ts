export interface CurrentUser {
  id: string
  email: string
  name: string
  surname: string
  role: string
  currentLesson: number
  currentLevel: number
  createdAt: string
  updatedAt: string
}
