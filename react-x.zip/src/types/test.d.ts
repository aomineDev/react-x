export type Test = Record<string, boolean>
