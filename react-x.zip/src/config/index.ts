export interface Config {
  API_URL: string
}

export const config: Config = Object.freeze({
  API_URL: 'http://localhost:3000',
})
