import { Hero } from '@/components/home/hero/Hero'

const HomePage = () => {
  return (
    <>
      <Hero />
    </>
  )
}

export default HomePage
